# Hyper-Trading Automation

This repository implements an event‑driven trading system with WebSocket‑first
market data, idempotent order management and built‑in risk controls.  It is
designed for small‑scale live trading and research.  See
[docs/production_readiness.md](docs/production_readiness.md) for remaining gaps
and steps required before high‑risk deployment.

## Features

- Fetch OHLCV price data from cryptocurrency exchanges using [CCXT](https://github.com/ccxt/ccxt) REST APIs and stream real-time candles via direct Binance/Bybit WebSocket endpoints (no CCXT Pro).
- Compute technical indicators such as moving averages, EMA, SuperTrend, RSI, MACD, Bollinger Bands, VWAP, On-Balance Volume,
  ADX, Stochastic oscillator, Rate of Change, TWAP, CCI, Keltner Channels, exchange net flow, volatility clustering index,
  Fibonacci retracements, WaveTrend oscillator, multi-timeframe RSI, volume profile point of control, Ichimoku Cloud,
  Parabolic SAR and a lightweight AI momentum signal.
- Basic sentiment analysis from NewsAPI headlines using VADER.
- Macro indicators from the FRED API (DXY, interest rates, liquidity).
- Enhanced strategy uses EMA crossovers, SuperTrend direction, RSI and Bollinger Band confirmation with optional sentiment filter for more reliable signals.
- Optional machine learning model using logistic regression to predict price direction. Includes a helper to cross-validate accuracy.
- Experimental transformer-based model and reinforcement-learning utilities for dynamic leverage selection.
- Automatic position sizing based on account balance and risk percentage.
- Integrated risk controls including dynamic leverage, drawdown throttling,
  trailing stops and volatility-scaled exits with persistent equity tracking.
- Advanced risk utilities providing AI-driven historical VaR, optional
  reinforcement-learning based throttling and SHAP explainability helpers.
- Volatility scanner that ranks symbols by ATR to focus on the most
  active markets.
- Basic testing suite and GitHub Actions workflow.
- On-chain gas fee analytics and order book imbalance filters for higher quality crypto signals.
- Depth-of-market heatmap ratios to flag potential iceberg orders.
- Enhanced machine learning features include MACD histogram, VWAP distance, OBV, volatility clustering, exchange net flow,
  WaveTrend, multi-timeframe RSI and distance from volume profile POC to better capture momentum, volume and on-chain pressure.
- Resilient data fetching with retry and optional exchange fallback.
- WebSocket data ingestion via direct exchange connections (no paid
  dependencies) with automatic heartbeat/reconnect and a minimal FIX
  execution skeleton for low-latency broker connectivity.
- Vectorized backtesting helper built on [vectorbt](https://github.com/vectorbt/vectorbt).
- Backtester accepts leverage to simulate capital amplification and risk.
- Multi-strategy helpers including basic arbitrage and market-making examples.
- Prop-firm style funding simulator for evaluating strategy robustness.
- Dockerfile for containerised deployment.
- Prometheus metrics and IsolationForest anomaly detection utilities for
  monitoring and compliance.
- Configuration schemas validated with ``pydantic``.

### Macro data

Providing a FRED API key allows the bot to fetch the US Dollar Index, federal
funds rate and M2 money stock. These values are combined into a macroeconomic
score that influences trading signals.

## Setup

1. **Create Python 3.10 Environment**:
```bash
conda create -n trading-py310 python=3.10 -y
conda activate trading-py310
```

2. **Install Dependencies**:
```bash
pip install -r requirements.txt
```

### Configuration

Runtime options such as default trading symbols and risk parameters are stored
in `config.yaml`. A `config.sample.yaml` is provided as a template – copy it to
`config.yaml` (which is git‑ignored) and adjust values for your environment.
API keys are **not** stored in the YAML file and should instead be supplied via
environment variables:

```bash
export FRED_API_KEY=your_fred_key
export NEWS_API_KEY=your_news_key
export ETHERSCAN_API_KEY=your_etherscan_key
```

You may also pass a custom config path to the bot using `--config`.

2. Run tests:

```bash
pytest -v
```
3. **Run Tests**:
```bash
pytest -v
```

## Quick Start

### 1. Fetch Real Market Data
```bash
cd scripts
python simple_data_fetch.py
```

### 2. Run Backtest
```bash
cd examples
python real_data_backtest_example.py
```

### 3. Run Live Bot (Paper Trading)
```bash
python -m hypertrader.bot BTC-USD --account_balance 10000 --risk_percent 2
```

When not operating live, the bot writes decisions to `signal.json` for offline inspection.

## Project Structure

```
Hyper-Trading-Automation/
├── hypertrader/           # Main package
│   ├── strategies/        # Trading strategies
│   ├── binance_bots/     # Binance-style bots
│   ├── data/             # Data fetching & storage
│   ├── risk/             # Risk management
│   ├── execution/        # Order execution
│   └── utils/            # Utilities & indicators
├── scripts/              # Data fetching scripts
├── examples/             # Backtest examples
├── data/                 # Market data & results
├── docs/                 # Documentation
└── tests/                # Test suite
```

### Running the autonomous bot

The `hypertrader.bot` module fetches data from supported exchanges via CCXT REST and consumes live candles from direct exchange WebSockets. When run in live mode it places orders via CCXT. When not live it writes a trading signal with calculated position size to `signal.json`. When multiple symbols are provided the bot will automatically trade the one with the highest recent volatility:

```bash
python -m hypertrader.bot BTC-USD ETH-USD --account_balance 10000 --risk_percent 5 \
     --fred_api_key YOUR_FRED_KEY \
     --model_path trained_model.pkl

# alternatively load options from config.yaml
python -m hypertrader.bot --config config.yaml

 ```

Alternatively set the `FRED_API_KEY` environment variable so the bot can
retrieve macroeconomic series without specifying the flag each run.

### Logging

The bot emits structured JSON logs with latency and other metrics. Redirect
stdout to a file or log processor to monitor live trading performance.

### Machine learning strategy

You can optionally train a simple logistic regression model on historical data.
The helper functions in `hypertrader.strategies.ml_strategy` make this easy:

```python
from hypertrader.strategies.ml_strategy import train_model, ml_signal
from hypertrader.data.fetch_data import fetch_ohlcv

data = fetch_ohlcv("binance", "BTC/USDT", timeframe="1m")
model = train_model(data)
sig = ml_signal(model, data)
print(sig)
model.to_pickle("trained_model.pkl")

# Evaluate accuracy using cross validation
from hypertrader.strategies.ml_strategy import cross_validate_model
print("CV", cross_validate_model(data))
The bot can load this model to confirm indicator-based signals for added
confidence.

Run the bot with the `--model_path` option to enable this behaviour:

```bash
python -m hypertrader.bot BTC-USD --model_path trained_model.pkl
```
