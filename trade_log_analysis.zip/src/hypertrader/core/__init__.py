"""Core event-driven trading engine components."""

from .pipeline import Pipeline

__all__ = ["Pipeline"]
